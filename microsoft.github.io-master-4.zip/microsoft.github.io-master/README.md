microsoft.github.io
===================

As Microsoft's open source presence and volume of released source code up on GitHub has
increased, we've reimagined the portal and index for our repos.

Today you can find, filter and review all sorts of open source up at https://opensource.microsoft.com.

At this time the site also continues to hold the official Microsoft Open Source Code of Conduct policy and
FAQ.

Feel free to email [opensource@microsoft.com](mailto:opensource@microsoft.com) if you have any questions about this site or Microsoft GitHub
organizations in general.


        microsoft.github.io/README.md
      
Skip to content
 
Search or jump to…

Pull requests
Issues
Marketplace
Explore
 @oscarg933 Sign out
Your account has been flagged.
Because of that, your profile is hidden from the public. If you believe this is a mistake, contact support to have your account status reviewed.
385
1,508 406 Microsoft/microsoft.github.io
 Code  Issues 2  Pull requests 15  Projects 0  Insights
Oscarg933.github.io #170
 Open	oscarg933 wants to merge 17 commits into Microsoft:master from oscarg933:master
+828 −397 
 Conversation 4   Commits 17   Checks 0   Files changed 15
Conversation
Reviewers
No reviews
Assignees
No one assigned
Labels
None yet
Projects
None yet
Milestone
No milestone
Notifications
You’re receiving notifications because you authored the thread.
1 participant
@oscarg933
  Allow edits from maintainers.
 @oscarg933
 
oscarg933 commented 13 days ago
No description provided.

oscarg933 added some commits 17 days ago
 @oscarg933
Create .travis.yml
5826a93
 @oscarg933
Create .codecov.yml
78aff76
 @oscarg933
Set theme jekyll-theme-tactile
74b0f4d
 @oscarg933
Update issue templates  …
494c8aa
 @oscarg933
Update .iot  …
93d065c
 @oscarg933
Update Gemfile  …
1d87ba0
 @oscarg933
Update LICENSE  …
e15e793
 @oscarg933
Update LICENSE  …
467e8ea
 @oscarg933
Update README.md
d807e4c
 @oscarg933
Update .gitignore
375ed62
 @oscarg933
Update index.md
6f4ac29
 @oscarg933
Update index.md
4c525ff
@oscarg933
oscarg933 reviewed 13 days ago
+1

@oscarg933
oscarg933 reviewed 13 days ago
+1

@oscarg933
oscarg933 reviewed 13 days ago
+1

@oscarg933
oscarg933 reviewed 13 days ago
1st_place_medal

@oscarg933
 Owner
oscarg933 commented on 1d87ba0 11 days ago
 octocat 1

oscarg933 added some commits 2 days ago
 @oscarg933
Create Juana Lopez
c4d04a4
 @oscarg933
Create Veneno.iot
4a5f71b
 @oscarg933
Update Veneno.iot
182e72b
 @oscarg933
Update .codecov.yml
1586100
@oscarg933
 Owner
oscarg933 commented on 1586100 3 minutes ago
[> [.Codecov.yml]](:1st_place_medal: )

 @oscarg933
Update custom.md
5dd023d
Merge state
Add more commits by pushing to the master branch on oscarg933/microsoft.github.io.

This branch has no conflicts with the base branch
Only those with write access to this repository can merge pull requests.
@oscarg933
   
 
 
 
Leave a comment
Attach files by dragging & dropping, selecting them, or pasting from the clipboard.

 Styling with Markdown is supported
 ProTip! Add .patch or .diff to the end of URLs for Git’s plaintext views.
© 2018 GitHub, Inc.
Terms
Privacy
Security
Status
Help
Contact GitHub
Pricing
API
Training
Blog
About
Press h to open a hovercard with more details.

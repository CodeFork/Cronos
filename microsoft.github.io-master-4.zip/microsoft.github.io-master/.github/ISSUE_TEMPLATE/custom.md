---
name: Custom issue template
about: Describe this issue template's purpose here.

---

https://github.com/oscarg933/ioBroker.homekit2.git
